<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda | Delta Subur Prima</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

    <link rel="icon" href="images/Logo.png">

</head>

<body>

    <!-- header section starts  -->

    <header class="header">

        <a href="index.php" class="logo">
            <img src="images/Logo.png" alt=""> Delta Subur Prima 
        </a>

        <nav class="navbar">
            <a href="#home">home</a>
            <a href="./produk/produk.php">produk</a>
            <a href="./berita/berita.php">berita</a>
            <a href="./galeri/galeri.php">galeri</a>
            <a href="index.php" style="background-color: red; padding: 4px; border-radius: 2px;">Logout</a>
        </nav>

    </header>

    <!-- header section ends -->

    <section class="main">
        <div class="content" style="color:white; 
        margin-top: 125px;
        font-size: 35px;
        text-align: center;
        ">
            <h3>SELAMAT DATANG DI HALAMAN ADMIN</h3>
            <h3>DELTA SUBUR PRIMA</h3>
            <img src="images/Logo.png" alt="">
        </div>
    </section>

    <!-- custom js file link  -->
    <script src="js/script.js"></script>

</body>

</html>