<?php 
require 'konek.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda | Delta Subur Prima</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

    <link rel="icon" href="images/Logo.png">

</head>

<body>

    <!-- header section starts  -->

    <header class="header">

        <a href="#" class="logo">
            <img src="images/Logo.png" alt=""> Delta Subur Prima
        </a>

        <nav class="navbar">
            <a href="#home">home</a>
            <a href="./produk/produk.php">produk</a>
            <a href="./berita/berita.php">berita</a>
            <a href="galeri.html">galeri</a>
        </nav>
    </header>

    <!-- header section ends -->

    <!-- custom js file link  -->
    <script src="js/script.js"></script>

</body>

</html>