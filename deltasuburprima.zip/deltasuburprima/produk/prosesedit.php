<?php 
	include('../konek.php');

	$id = $_POST['id'];
	$nama = $_POST['nama'];
	$stok = $_POST['stok'];
	$harga = $_POST['harga'];
	$ket_produk = $_POST['ket_produk'];
	$gambar = $_FILES['gambar']['name'];

	if ($gambar != "") {
		$boleh = array('png', 'jpg');
		$x = explode('.', $gambar);
		$ekstensi = strtolower(end($x));
		$file_tmp = $_FILES['gambar']['tmp_name'];
		$random_angka = rand(1, 999);
		$nama_gambar_baru = $random_angka."-".$gambar;

		if (in_array($ekstensi, $boleh) === true) {
			move_uploaded_file($file_tmp, '../gambar/'.$nama_gambar_baru);

			$query = "UPDATE produk SET nama='$nama',stok='$stok',harga = '$harga',ket_produk = '$ket_produk',gambar = '$nama_gambar_baru' WHERE id_produk = '$id'";
			$result = mysqli_query($koneksi, $query);

			if(!$result){
                    die("Query Error : ".mysqli_errno($koneksi))." - ".mysqli_error($koneksi);
            }else{
            	echo" <script>alert('Data berhasil diubah'); window.location='produk.php'</script>";
            }
		}else {
			echo" <script>alert('Ekstensi gambar hanya bisa dalam png dan jpg!'); window.location='editproduk.php'</script>";
		}
	}else{
		$query = "UPDATE produk SET nama = '$nama',stok = '$stok',harga = '$harga',ket_produk = '$ket_produk' WHERE id_produk = '$id'";
		$result = mysqli_query($koneksi, $query);

		if(!$result){
            die("Query Error : ".mysqli_errno($koneksi))." - ".mysqli_error($koneksi);
        }else{
           	echo" <script>alert('Data berhasil diubah'); window.location='produk.php'</script>";
        }
	}
?>