<?php 
include('../konek.php');
$id = $_GET['id'];
$query = "DELETE FROM produk WHERE id_produk= '$id'";
$result = mysqli_query($koneksi, $query);

if(!$result){
    die("Query Error : ".mysqli_errno($koneksi))." - ".mysqli_error($koneksi);
}else{
    echo" <script>alert('Data berhasil dihapus'); window.location='produk.php'</script>";
	}
?>