<?php
include('../konek.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda | Delta Subur Prima</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="icon" href="../images/Logo.png">

</head>

<body>

    <!-- header section starts  -->
    <header class="header">

        <a href="#" class="logo">
            <img src="../images/Logo.png" alt=""> Delta Subur Prima
        </a>

        <nav class="navbar">
            <a href="../dashboardadm.php">home</a>
            <a href="produk.php">produk</a>
            <a href="../berita/berita.php">berita</a>
            <a href="../galeri/galeri.php">galeri</a>
            <a href="../index.php" style="background-color: red; padding: 4px; border-radius: 2px;">Logout</a>
        </nav>
    </header>

    <!-- header section ends -->
    <section class="about" id="about">
        <h1 class="heading"> <span>Tentang </span> Kami </h1>
        <h1 class="heading"> <span>Data </span> Produk </h1>
        <div class="row">
            <div class="content"><br>
                <center><a href="tambahproduk.php" style="background-color: blue;
                color: white;
                padding: 10px; 
                border-radius: 10px;
                margin:10px;
                font-size: medium; 
                font-family: sans-serif;">Tambah Produk</a></center> <br>
                <table style="
        border: 1px solid #ddeeee;
        border-collapse: collapse;
        border-spacing: 0;
        width: 90%;
        margin: 10px auto 10px auto;">
                    <thead style="
             background-color: lightgray;
            border: 1px solid #ddeeee;
            color: #000; 
            padding: 10px;
            text-align: left;
            text-shadow: 1px 1px 1px white;">

                        <tr style="font-size: medium;">
                            <th style="padding: 10px">No.</th>
                            <th style="padding: 10px">Nama Produk</th>
                            <th style="padding: 10px">Stok</th>
                            <th style="padding: 10px">Harga</th>
                            <th style="padding: 10px">Keterangan Produk</th>
                            <th style="padding: 10px">Gambar</th>
                            <th style="padding: 10px">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = "SELECT * FROM produk ORDER BY id_produk ASC";
                        $result = mysqli_query($koneksi, $query);

                        if (!$result) {
                            die("Query Error : " . mysqli_errno($koneksi)) . " - " . mysqli_error($koneksi);
                        }

                        $no = 1;

                        while ($row = mysqli_fetch_assoc($result)) {

                        ?>
                            <tr style="font-size:medium; color: white;">
                                <td style="padding: 10px"><?php echo $no; ?></td>
                                <td style="padding: 10px"><?php echo $row['nama']; ?></td>
                                <td style="padding: 10px"><?php echo number_format($row['stok'], 0, ',', '.'); ?></td>
                                <td style="padding: 10px">Rp<?php echo number_format($row['harga'], 0, ',', '.'); ?></td>
                                <td style="padding: 10px"><?php echo substr($row["ket_produk"], 0, 20); ?>...</td>
                                <td style="padding: 10px"><img style="width: 150px;" src="../gambar/<?php echo $row['gambar']; ?>"></td>
                                <td style="padding: 10px">
                                    <a style="
                background-color: yellowgreen;
                color: #fff;
                padding: 10px; border-radius: 10px; margin: 15px" href="editproduk.php?id=<?php echo $row['id_produk']; ?>">Edit</a>
                                    <a style="
                background-color: orangered;
                color: #fff;
                padding: 10px; border-radius: 10px" href="proseshapus.php?id=<?php echo $row['id_produk']; ?>">Hapus</a>
                                </td>
                            </tr>
                        <?php
                            $no++;
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>

    </section>

    <!-- custom js file link  -->
    <script src="js/script.js"></script>

</body>

</html>