<?php 
include('../konek.php');

    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $query = "SELECT * FROM berita WHERE id_berita = '$id'";
        $result = mysqli_query($koneksi, $query);
        if (!$result) {
            die("Query Error: ".mysqli_errno($koneksi)."-".mysqli_error($koneksi));
        }
        $data= mysqli_fetch_assoc($result);

        if (!count($data)) {
            echo"<script>alert('Data tidak ditemukan pada tabel');window.location='produk.php';</script>";
        }
    }else{
        echo "<script>alert('Masukkan ID yang ingin diedit');window.location='produk.php';</script>";
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda | Delta Subur Prima</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="icon" href="../images/Logo.png">

</head>

<body>

    <!-- header section starts  -->
    <header class="header">

        <a href="#" class="logo">
            <img src="../images/Logo.png" alt=""> Delta Subur Prima
        </a>

        <nav class="navbar">
            <a href="../dashboard.php">home</a>
            <a href="./produk/produk.php">produk</a>
            <a href="berita.php">berita</a>
            <a href="../galeri/galeri.php">galeri</a>
        </nav>
    </header>
        
    <!-- header section ends -->
    <section class="about" id="about">
        <h1 class="heading"> <span>Tentang </span> Kami </h1>
        <h1 class="heading"> <span>edit  berita</span> <?php echo $data['judul'];?></h1>
        <div class="row">
            <div class="content"><br>
                <form method="POST" action="proseseditberita.php" enctype="multipart/form-data">
                <section class="base" style="color:white;
                width: 400px;
                padding: 20px;
                margin-left: auto;
                margin-right: auto;">

                    <div>
                        <label for="" style="
                        margin-top: 10px;
                        float: left;
                        text-align: left ;
                        width: 100%;
                        font-size: medium;
                        ">Judul Berita</label>
                        <input type="text" name="judul" 
                        autofocus="" required="" value="<?php echo $data['judul'];?>" style="
                        padding: 6px;
                        width: 100%;
                        box-sizing: border-box;
                        border: 2px solid #ccc;
                        outline-color: gray;"/>
                        <input type="hidden" name="id"value="<?php echo $data['id_berita'];?>"/>
                    </div>
                    <div>
                        <label for=""style="
                        margin-top: 10px;
                       
                        width: 100%;font-size: medium;
                        ">Keterangan</label>
                    <!--    <input type="text" name="ket_berita" value="<?php echo $data['ket_berita'];?>" style="
                        padding: 6px;
                        width: 100%;
                        box-sizing: border-box;
                        border: 2px solid #ccc;
                        outline-color: gray;"/> -->
                    </div>
                    <textarea name="ket_berita" rows="15" cols="80">

</textarea>
                    <div>
                        <label for=""style="
                        margin-top: 10px;
                        float: left;
                        text-align: left ;
                        width: 100%;font-size: medium;
                        ">Gambar Berita</label>
                        <img src="../gambar/<?php echo $data['gambar']; ?>" style="width: 150px; float: left; margin-bottom: 5px;" alt="">
                        <input type="file" name="gambar" style="
                        padding: 6px;
                        width: 100%;
                        box-sizing: border-box;
                        border: 2px solid #ccc;
                        outline-color: gray;"/>
                    </div>
                    <div>
                        <button class="btn" type="submit">Update</button>
                    </div>
                </section>
                </form>
            </div>
        </div>

    </section>

    <!-- custom js file link  -->
    <script src="js/script.js"></script>
    <script type="text/javascript" src="../js/tinymce/js/tinymce/tinymce.min.js"></script>
    <script type="text/javascript">
        tinymce.init({
            selector: "textarea",
            plugins: ["advlist autolink lists link image charmap print preview anchor", "searchreplace visualblocks code fullscreen", "insertdatetime media table contextmenu paste jbimages"],

            toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image jbimages",

            relative_urls: false
        });
    </script>

</body>

</html>