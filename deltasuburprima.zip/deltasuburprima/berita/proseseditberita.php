<?php 
    include('../konek.php');

    $id = $_POST['id'];
    $judul = $_POST['judul'];
    $ket_berita = $_POST['ket_berita'];
    $gambar = $_FILES['gambar']['name'];

    if ($gambar != "") {
        $boleh = array('png', 'jpg');
        $x = explode('.', $gambar);
        $ekstensi = strtolower(end($x));
        $file_tmp = $_FILES['gambar']['tmp_name'];
        $random_angka = rand(1, 999);
        $nama_gambar_baru = $random_angka."-".$gambar;

        if (in_array($ekstensi, $boleh) === true) {
            move_uploaded_file($file_tmp, '../gambar/'.$nama_gambar_baru);

            $query = "UPDATE berita SET judul='$judul',ket_berita = '$ket_berita' , gambar = '$nama_gambar_baru' WHERE id_berita = '$id'";
            $result = mysqli_query($koneksi, $query);

            if(!$result){
                    die("Query Error : ".mysqli_errno($koneksi))." - ".mysqli_error($koneksi);
            }else{
                echo" <script>alert('Data berhasil diubah'); window.location='berita.php'</script>";
            }
        }else {
            echo" <script>alert('Ekstensi gambar hanya bisa dalam png dan jpg!'); window.location='editberita.php'</script>";
        }
    }else{
        $query = "UPDATE berita SET judul='$judul',ket_berita = '$ket_berita' WHERE id_berita = '$id'";
        $result = mysqli_query($koneksi, $query);

        if(!$result){
            die("Query Error : ".mysqli_errno($koneksi))." - ".mysqli_error($koneksi);
        }else{
            echo" <script>alert('Data berhasil diubah'); window.location='berita.php'</script>";
        }
    }
?>
