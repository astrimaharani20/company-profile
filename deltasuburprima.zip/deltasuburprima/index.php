<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delta Subur Prima</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

    <link rel="icon" href="images/Logo.png">

</head>

<body>

    <!-- header section starts  -->

    <header class="header">

        <a href="index.php" class="logo">
            <img src="images/Logo.png" alt=""> Delta Subur Prima
        </a>

        <nav class="navbar">
            <a href="#home">home</a>
            <a href="#menu">produk</a>
            <a href="#berita">berita</a>
            <a href="#galeri">galeri</a>
            <a href="#contact">contact</a>
            <a href="#profile">profile</a>
            <a href="login.php" style="background:local;  padding: 4px; border-radius: 2px;"> <i class="fa fa user"></i>admin</a>
        </nav>

        <div class="icons">
            <div class="fas fa-bars" id="menu-btn"></div>
        </div>



    </header>

    <!-- header section ends -->

    <!-- home section starts  -->

    <section class="home" id="home">

        <div class="content">
            <h3>Delta Subur Prima</h3>
            <p>Toko obat pertanian yang menjual berbagai macam produk obat kimia untuk tanaman</p>
            <p>Untuk mengetahui info lebih lengkap mengenai produk dapat dilihat pada menu produk Pemesanan produk dapat dilakukan melalui whatsapp customer service</p>

        </div>

    </section>

    <!-- home section ends -->

    <!-- menu section starts  -->

    <section class="menu" id="menu">

        <h1 class="heading"> Produk <span>Kami</span> </h1>


        <div class="box-container">
            <?php
            include "konek.php";

            $modal = mysqli_query($koneksi, "SELECT * from produk ORDER BY id_produk");
            while ($r = mysqli_fetch_array($modal)) {
                $id = $r['id_produk'];
                $harga = $r['harga'];
                $nama = $r['nama'];
                $stok = $r['stok'];
                $ket_produk = $r['ket_produk'];

            ?>
                <div class="box">

                    <img src="gambar/<?= $r['gambar'];  ?>" alt="">
                    <h3><?php echo $nama;  ?></h3>
                    <div class="price">Rp <?php echo number_format($r['harga'], 0, ',', '.'); ?>/kg</div>
                    <div class="price">Stok: <?php echo $stok; ?></div>
                    <a href="produk.php?id_produk=<?php echo $r['id_produk']; ?>" class="btn">Selengkapnya</a>
                </div>
            <?php } ?>

    </section>
    <!-- menu section ends -->

    <!-- berita section starts -->

    <section class="berita" id="berita">

        <h1 class="heading"><span>BERITA</span> </h1>

        <div class="box-container">
            <?php

            $modal2 = mysqli_query($koneksi, "SELECT * from berita ORDER BY id_berita");
            while ($r = mysqli_fetch_array($modal2)) {
                $id = $r['id_berita'];
                $judul = $r['judul'];
                $ket_berita = $r['ket_berita'];

            ?>

                <div class="box">
                    <img src="gambar/<?= $r['gambar'] ?>" alt="" >
                    <h3><?php echo $judul; ?></h3>
                    <div class="artikel"></div>
                    <a href="berita.php?url_judul=<?php echo $r['url_judul']; ?>" class="btn">Selengkapnya</a>
                </div>
            <?php } ?>


        </div>

    </section>

    <!-- berita section ends -->

    <!-- galeri section starts -->

    <section class="berita" id="galeri">
        <h1 class="heading"><span>Galeri Foto</span> </h1>
        <div class="box-container">
            <?php

            $modal3 = mysqli_query($koneksi, "SELECT * from galeri ORDER BY id_foto");
            while ($r = mysqli_fetch_array($modal3)) {
                $ket_gambar = $r['ket_gambar'];

            ?>
                <div class="box">
                    <img src="gambar/<?= $r['gambar'] ?>" alt="" style="width: 300px; height: 200px;">
                    <h3><?php echo $ket_gambar; ?></h3>
                </div>
            <?php } ?>

        </div>

    </section>

    <!-- galeri section ends -->

    <!-- contact section starts  -->

    <section class="contact" id="contact">

        <h1 class="heading"> <span>Hubungi</span> Kami </h1>
        <div class="content" style="color:white; 
        
        text-align: center;">
            <center>
                <table style="color: white; border:1px solid white; font-size: 22px; padding: 15px;">
                    <tr>
                        <td style="padding-right: 25px;">Alamat</td>
                        <td>: Jl. Kalimantan No. 122 Sananwetan Kota Blitar</td>
                    </tr>
                    <tr>
                        <td>No Telp</td>
                        <td>: 081232572459</td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td>: sucipto@gmail.com</td>
                    </tr>
                </table>
            </center><br><br>
            <h4 style="font-size: 35px;">LOKASI KANTOR</h4><br>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3949.9604393989766!2d112.1807819!3d-8.1055107!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e78ec79911a3729%3A0x9a5fc15b7ba6d6b8!2sJl.%20Kalimantan%20No.79%2C%20Sananwetan%2C%20Kec.%20Sananwetan%2C%20Kota%20Blitar%2C%20Jawa%20Timur%2066137!5e0!3m2!1sid!2sid!4v1654173606019!5m2!1sid!2sid" width="600" height="450" style="border:1.5px solid gray;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>

    </section>

    <!-- contact section ends -->

    <!-- profile section starts -->

    <section class="main" id="profile">
        <div class="content" style="color:white; 
        font-size: 35px;
        text-align: center;
        ">
            <h4>PROFILE PEMILIK </h4>
            <h4>DELTA SUBUR PRIMA</h4>
            <img style="height: 300px; width:200px;" src="images/pp.png" alt="">
            <h5>SUCIPTO</h5>
        </div>
    </section>

    <!-- profile section ends -->

    <!-- custom js file link  -->
    <script src="js/script.js"></script>
    <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>


</body>

</html>