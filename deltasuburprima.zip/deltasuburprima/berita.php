<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda | Delta Subur Prima</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="http://localhost:8080/deltasuburprima/css/style.css">

    <link rel="icon" href="http://localhost:8080/deltasuburprima/images/Logo.png">

</head>

<body>

    <!-- header section starts  -->

    <header class="header">

        <a href="index.php" class="logo">
            <img src="http://localhost:8080/deltasuburprima/images/Logo.png" alt=""> Delta Subur Prima
        </a>

        <nav class="navbar">
            <a href="http://localhost:8080/deltasuburprima/#home">home</a>
            <a href="index.php">produk</a>
            <a href="index.php">contact</a>
            <a href="index.php">berita</a>
            <a href="index.php">galeri</a>
            <a href="index.php"> profile</a>
            <a href="login.php" style="background:local; padding: 4px; border-radius: 2px;">Admin</a>
        </nav>

        <div class="icons">
            <div class="fas fa-bars" id="menu-btn"></div>
        </div>



    </header>

    <!-- about section starts  -->

    <section class="about" id="about">
        <h1 class="heading"> <span>Tentang </span> Kami </h1>
        <div class="row">
            <?php
            include "konek.php";
            $id = $_GET['url_judul'];
            $modal4 = mysqli_query($koneksi, "SELECT * from berita WHERE url_judul = '$id'");
            while ($r = mysqli_fetch_array($modal4)) {
                $gambar = $r['gambar'];
                $ket_berita = $r['ket_berita'];

            ?>

                <div class="image" >
                    <img src="http://localhost:8080/deltasuburprima/gambar/<?php echo $gambar; ?>" alt="">
                </div>
                <div class="content"> <?php echo $ket_berita; ?>
                    <!--    <h3>Lorem, ipsum dolor.</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem soluta iure architecto impedit.</p>
                <p>
                <p>Lorem ipsum, dolor sit amet consectetur, adipisicing elit. Fugiat ab, quae quo pariatur animi rerum
                    sed, quasi officiis magni sapiente iure est corrupti. Corporis repudiandae dignissimos tempore
                    maiores facere sed.</p> 
                </p> -->
                </div>
            <?php } ?>
        </div>

    </section>

    <!-- custom js file link  -->
    <script src="http://localhost:8080/deltasuburprima/js/script.js"></script>

</body>

</html>