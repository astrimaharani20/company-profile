<?php 
	include('../konek.php');

	$ket_gambar = $_POST['ket_gambar'];
	$gambar = $_FILES['gambar']['name'];

	if ($gambar != "") {
		$boleh = array('png', 'jpg');
		$x = explode('.', $gambar);
		$ekstensi = strtolower(end($x));
		$file_tmp = $_FILES['gambar']['tmp_name'];
		$random_angka = rand(1, 999);
		$nama_gambar_baru = $random_angka."-".$gambar;

		if (in_array($ekstensi, $boleh) === true) {
			move_uploaded_file($file_tmp,'../gambar/'.$nama_gambar_baru);

			$query = "INSERT INTO galeri (ket_gambar, gambar) VALUES ('$ket_gambar', '$nama_gambar_baru')";
			$result = mysqli_query($koneksi, $query);

			if(!$result){
                    die("Query Error : ".mysqli_errno($koneksi))." - ".mysqli_error($koneksi);
            }else{
            	echo"<script>alert('Data berhasil ditambahkan');window.location='galeri.php'</script>";
            }
		}else {
			echo"<script>alert('Ekstensi gambar hanya bisa dalam png dan jpg!'); window.location='tambahberita.php'</script>";
		}
	}else{
		$query = "INSERT INTO galeri (ket_gambar) VALUES ('$ket_gambar')";
			$result = mysqli_query($koneksi, $query);

			if(!$result){
                    die("Query Error : ".mysqli_errno($koneksi))." - ".mysqli_error($koneksi);
            }else{
            	echo "<script>alert('Data berhasil ditambahkan'); window.location='galeri.php</script>";
            }
	}
?>
