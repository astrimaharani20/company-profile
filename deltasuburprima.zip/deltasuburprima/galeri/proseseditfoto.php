<?php 
    include('../konek.php');

    $id = $_POST['id'];
    $ket_gambar = $_POST['ket_gambar'];
    $gambar = $_FILES['gambar']['name'];

    if ($gambar != "") {
        $boleh = array('png', 'jpg');
        $x = explode('.', $gambar);
        $ekstensi = strtolower(end($x));
        $file_tmp = $_FILES['gambar']['tmp_name'];
        $random_angka = rand(1, 999);
        $nama_gambar_baru = $random_angka."-".$gambar;

        if (in_array($ekstensi, $boleh) === true) {
            move_uploaded_file($file_tmp, '../gambar/'.$nama_gambar_baru);

            $query = "UPDATE galeri SET ket_gambar = '$ket_gambar', gambar = '$nama_gambar_baru' WHERE id_foto = '$id'";
            $result = mysqli_query($koneksi, $query);

            if(!$result){
                    die("Query Error : ".mysqli_errno($koneksi))." - ".mysqli_error($koneksi);
            }else{
                echo" <script>alert('Data berhasil diubah'); window.location='galeri.php'</script>";
            }
        }else {
            echo" <script>alert('Ekstensi gambar hanya bisa dalam png dan jpg!'); window.location='editberita.php'</script>";
        }
    }else{
        $query = "UPDATE galeri SET ket_gambar = '$ket_gambar' WHERE id_foto = '$id'";
        $result = mysqli_query($koneksi, $query);

        if(!$result){
            die("Query Error : ".mysqli_errno($koneksi))." - ".mysqli_error($koneksi);
        }else{
            echo" <script>alert('Data berhasil diubah'); window.location='galeri.php'</script>";
        }
    }
?>
