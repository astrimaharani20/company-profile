<?php 
include('../konek.php');

    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $query = "SELECT * FROM galeri WHERE id_foto = '$id'";
        $result = mysqli_query($koneksi, $query);
        if (!$result) {
            die("Query Error: ".mysqli_errno($koneksi)."-".mysqli_error($koneksi));
        }
        $data= mysqli_fetch_assoc($result);

        if (!count($data)) {
            echo"<script>alert('Data tidak ditemukan pada tabel');window.location='galeri.php';</script>";
        }
    }else{
        echo "<script>alert('Masukkan ID yang ingin diedit');window.location='galeri.php';</script>";
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda | Delta Subur Prima</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="icon" href="../images/Logo.png">

</head>

<body>

    <!-- header section starts  -->
    <header class="header">

        <a href="#" class="logo">
            <img src="../images/Logo.png" alt=""> Delta Subur Prima
        </a>

        <nav class="navbar">
            <a href="../dashboard.php">home</a>
            <a href="./produk/produk.php">produk</a>
            <a href="../berita/berita.php">berita</a>
            <a href="galeri.php">galeri</a>
        </nav>
    </header>
        
    <!-- header section ends -->
    <section class="about" id="about">
        <h1 class="heading"> <span>Tentang </span> Kami </h1>
        <h1 class="heading"> <span>edit gambar / foto</span></h1>
        <div class="row">
            <div class="content"><br>
                <form method="POST" action="proseseditfoto.php" enctype="multipart/form-data">
                <section class="base" style="color:white;
                width: 400px;
                padding: 20px;
                margin-left: auto;
                margin-right: auto;">
                 <div>
                        <label for=""style="
                        margin-top: 10px;
                        float: left;
                        text-align: left ;
                        width: 100%;font-size: medium;
                        ">Gambar</label>
                        <img src="../gambar/<?php echo $data['gambar']; ?>" style="width: 150px; float: left; margin-bottom: 5px;" alt="">
                        <input type="file" name="gambar" required=""style="
                        padding: 6px;
                        width: 100%;
                        box-sizing: border-box;
                        border: 2px solid #ccc;
                        outline-color: gray;"/>
                    </div>
                    <div>
                        <label for=""style="
                        margin-top: 10px;
                        float: left;
                        text-align: left ;
                        width: 100%;font-size: medium;
                        ">Keterangan</label>
                        <input type="text" name="ket_gambar" value="<?php echo $data['ket_gambar'];?>" style="
                        padding: 6px;
                        width: 100%;
                        box-sizing: border-box;
                        border: 2px solid #ccc;
                        outline-color: gray;"/>
                        <input type="hidden" name="id"value="<?php echo $data['id_foto'];?>"/>
                    </div>
                    <div>
                        <button class="btn" type="submit">Update</button>
                    </div>
                </section>
                </form>
            </div>
        </div>

    </section>

    <!-- custom js file link  -->
    <script src="js/script.js"></script>

</body>

</html>