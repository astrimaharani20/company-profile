<?php 
include('../konek.php');
$id = $_GET['id'];
$query = "DELETE FROM galeri WHERE id_foto= '$id'";
$result = mysqli_query($koneksi, $query);

if(!$result){
    die("Query Error : ".mysqli_errno($koneksi))." - ".mysqli_error($koneksi);
}else{
    echo" <script>alert('Berita berhasil dihapus'); window.location='galeri.php'</script>";
	}
?>