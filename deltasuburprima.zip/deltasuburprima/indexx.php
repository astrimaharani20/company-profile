<?php
require 'konek.php';

if (isset($_POST['login'])) {
    $user = $_POST["username"];
    $pw   = $_POST['password'];

    $sql = mysqli_query($koneksi, "SELECT * FROM admin WHERE username = '$user'");

    if (mysqli_num_rows($sql) === 1) {
        $row = mysqli_fetch_assoc($sql);
        if (password_verify($pw, $row['password'])) {
            header("location:homeadm.php");
            exit;
        }
    }
    $eror = true;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda | Delta Subur Prima</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

    <link rel="icon" href="images/Logo.png">

</head>

<body>

    <!-- header section starts  -->

    <header class="header">

        <a href="index.php" class="logo">
            <img src="images/Logo.png" alt=""> Delta Subur Prima
        </a>





    </header>

    <body>

        <div class="container">
            <h1>LOGIN ADMIN</h1>
            <?php
            if (isset($_GET['pesan'])) {
                if ($_GET['pesan'] == "gagal") {
                    // echo "Silahkan Masukan Password!";
                } else if ($_GET['pesan'] == "belum_login") {
                    echo "Anda harus login untuk mengakses halaman admin";
                }
            }
            ?>

            <form action="login.php" method="post">
                <input type="text" name="username" id="username" placeholder="Username" />
                <input type="password" name="password" id="password" placeholder="Password" />

                <button class="btn" name="login" type="submit" value="LOGIN">Login</button>
            </form>
        </div>


    </body>

    <!-- header section ends -->

    <!-- custom js file link  -->
    <script src="js/script.js"></script>

</body>

</html>